package copamundial.modelo;

/**
 * Representa a un jugador de futbol dentro del plantel de un pais.
 * Estructura de datos primitiva: no depende de ninguna coleccion dinamica.
 */
public class Jugador {

    private String nombre;
    private int dorsal;
    private String posicion; // Portero, Defensa, Mediocampista, Delantero
    private int edad;

    public Jugador() {
        this.nombre = "";
        this.dorsal = 0;
        this.posicion = "";
        this.edad = 18;
    }

    public Jugador(String nombre, int dorsal, String posicion, int edad) {
        this.nombre = nombre;
        this.dorsal = dorsal;
        this.posicion = posicion;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return dorsal + " - " + nombre + " (" + posicion + ")";
    }
}
