package copamundial.modelo;

import java.util.Random;

// Partido del calendario los eventos se almacenan en un arreglos fijos Benjamin Roque
public class Partido {

    private static final int MAX_EVENTOS = 24;
    private final PosicionGrupo local;
    private final PosicionGrupo visitante;
    private final int numeroGrupo;
    private final String[] eventos = new String[MAX_EVENTOS];
    private int cantidadEventos;
    private int golesLocal;
    private int golesVisitante;
    private boolean jugado;

    public Partido(PosicionGrupo local, PosicionGrupo visitante, int numeroGrupo) {
        this.local = local;
        this.visitante = visitante;
        this.numeroGrupo = numeroGrupo;
    }

    public void simular(Random random) {
        if (jugado) return;
        golesLocal = random.nextInt(6);
        golesVisitante = random.nextInt(6);
        registrarGoles(local.getPais(), golesLocal, random);
        registrarGoles(visitante.getPais(), golesVisitante, random);
        registrarTarjetas(local.getPais(), random);
        registrarTarjetas(visitante.getPais(), random);
        local.registrarResultado(golesLocal, golesVisitante);
        visitante.registrarResultado(golesVisitante, golesLocal);
        jugado = true;
    }

    private void registrarGoles(Pais pais, int cantidad, Random random) {
        for (int i = 0; i < cantidad; i++) {
            Jugador jugador = jugadorAleatorio(pais, random);
            agregarEvento("GOL - " + nombreJugador(jugador, pais));
        }
    }

    private void registrarTarjetas(Pais pais, Random random) {
        int amarillas = random.nextInt(5);
        int rojas = random.nextInt(2);
        for (int i = 0; i < amarillas; i++) {
            agregarEvento("Amarilla - " + nombreJugador(jugadorAleatorio(pais, random), pais));
        }
        for (int i = 0; i < rojas; i++) {
            agregarEvento("Roja - " + nombreJugador(jugadorAleatorio(pais, random), pais));
        }
    }

    private Jugador jugadorAleatorio(Pais pais, Random random) {
        if (pais.getCantidadJugadores() == 0) return null;
        return pais.getJugadores()[random.nextInt(pais.getCantidadJugadores())];
    }

    private String nombreJugador(Jugador jugador, Pais pais) {
        return (jugador == null ? "Jugador sin registrar" : jugador.getNombre())
                + " (" + pais.getNombre() + ")";
    }

    private void agregarEvento(String evento) {
        if (cantidadEventos < eventos.length) eventos[cantidadEventos++] = evento;
    }

    public String obtenerResumen() {
        String texto = "Grupo " + (char) ('A' + numeroGrupo) + ": "
                + local.getPais().getNombre() + " " + golesLocal + " - "
                + golesVisitante + " " + visitante.getPais().getNombre() + "\n";
        for (int i = 0; i < cantidadEventos; i++) texto += "   " + eventos[i] + "\n";
        return texto;
    }

    public boolean isJugado() { return jugado; }
    public PosicionGrupo getLocal() { return local; }
    public PosicionGrupo getVisitante() { return visitante; }
    public int getNumeroGrupo() { return numeroGrupo; }
}
